# Bhola Ji Innovation

This is the official website for Bhola Ji Innovation – a professional interior design service. Built with clean HTML/CSS and a light theme, it includes features like services listing and an image upload form.
